
#include "mbed.h"
#include "DHT.h"
#include "Adafruit_SSD1306.h"

DHT sensor1(p19, DHT11);
AnalogIn tanque(p16);
Serial pc(USBTX, USBRX);
AnalogIn sensor(p17);
BusOut lights(LED1, LED2, LED3, LED4);
SPI oled(p11,p12,p13);
Adafruit_SSD1306_Spi lcd(oled,p14,p9,p8,32,128);
Serial blue(p28, p27);
DigitalOut bomba(p22);

char valor[40];
char valor1[40];
char valor2[40];
char valor3[40];

int main()
{

    blue.baud(9600);
    pc.baud(9600);
    pc.printf("Bluetooth Start\r\n");

    int error = 0;
    float h = 0.0f, c = 0.0f;

    while(1) {
        float nivel = abs(tanque.read()*100. - 100)*2.7;
        nivel > 98 ? nivel = 100 : nivel = nivel;
        lcd.clearDisplay();
        sprintf(valor,"Umidade Solo:%.2f\n", nivel);
        lcd.setTextCursor(0,0);
        for (int i=0; i<strlen(valor); i++) {
            lcd.writeChar(valor[i]);
        }
        lcd.display();
        blue.puts(valor);
        blue.puts("\n");
        if (nivel < 20){
            blue.puts("Umidade do Solo baixa\n");
            blue.puts("\n");
            }
        
        if(nivel < 30) {
        bomba = 1;
         } else {
        bomba =0;
         }

        float val;
        float threshold = .7; //User specified for night-light mode. Set to .03 for light measurement mode
        val = sensor.read();
        sprintf(valor1,"Luminosidade:%.2f\n",sensor.read());
        lcd.setTextCursor(0,10);
        for (int i=0; i<strlen(valor1); i++) {
            lcd.writeChar(valor1[i]);
        }
        lcd.display();
        blue.puts(valor1);
        blue.puts("\n");
        if (val > .7){
            blue.puts("Baixa Luminosidade\n");
            blue.puts("\n");
            }
        wait(2.0f);
        //lcd.
        //Uncomment the line below for debugging.
        // printf("Sensor reading: %2.2f - %2.2f\r\n", val, (float)(1023-val)*10/val); //print through debug serial connection

        if(val >= threshold)

            lights = 15; //set all bus lines to 1
        else
            lights = 0; //set all bus lines to 0

        sensor1.readData();

        wait(3);
        //lcd.cls();
        if (0 == error) {
            c   = sensor1.ReadTemperature(CELCIUS);
            h   = sensor1.ReadHumidity();
            lcd.clearDisplay();
            sprintf(valor2,"Temperatura: %4.2f\n",c);
            sprintf(valor3,"Umidade: %4.2f\n",h);
            lcd.setTextCursor(0,0);
            for (int i=0; i<strlen(valor2); i++) {
                lcd.writeChar(valor2[i]);
            }
            lcd.display();
            blue.puts(valor2);
            blue.puts("\n");
            for (int i=0; i<strlen(valor3); i++) {
                lcd.writeChar(valor3[i]);
            }
            lcd.display();
            blue.puts(valor3);
            blue.puts("\n");

            wait(2.0f);
        }
    }
}